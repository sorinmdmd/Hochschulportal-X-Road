package org.niis.example.restapi.core.fault

class MemberExistsException(message: String) : RuntimeException(message)
