package org.niis.example.restapi.core.fault

class MemberNotFoundException(message: String) : RuntimeException(message)
